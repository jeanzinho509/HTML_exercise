# lanfing-page_horror_game
uma landing page de um jogo de terro feito durante a jornada de aprendizado do zero a primeira vaga da rokectseat usando HTML e CSS <br>
<img src='https://user-images.githubusercontent.com/100792438/225322164-b4d79bf6-23b0-40b4-a4e9-c3ae97e49e92.png'>


